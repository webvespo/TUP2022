﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            InitializeData();
        }

        public async Task InitializeData()
        {
            var weather = await GetWeatherSecondWay();

            foreach (var weatherEntry in weather)
            {
                var tempInC = "Temperatura en grados centigrados: " + weatherEntry.TemperatureC.ToString();
                richTextBox1.AppendText("\r\n" + tempInC);
                richTextBox1.ScrollToCaret();
            }       
        }

        private async Task<IEnumerable<WeatherForecast>> GetWeather()
        {
            string path = "http://localhost:24561/WeatherForecast";
            HttpClient client = new HttpClient();
            HttpResponseMessage resp = client.GetAsync(path).Result;
            resp.EnsureSuccessStatusCode();
            var response = resp.Content.ReadAsAsync<IEnumerable<WeatherForecast>>().Result;
            return response;
        }

        private async Task<IEnumerable<WeatherForecast>> GetWeatherSecondWay()
        {
            string path = "/WeatherForecast";
            return await RestApiClient.GetEntity<IEnumerable<WeatherForecast>>(path);
        }
    }
}