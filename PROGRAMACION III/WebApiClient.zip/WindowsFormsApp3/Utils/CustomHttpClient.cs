﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace WindowsFormsApp3
{
    internal class CustomHttpClient : HttpClient
    {
        public CustomHttpClient(Uri baseAddress)
            : base(new CustomDelegatingHandler(new HttpClientHandler()))
        {
            BaseAddress = baseAddress;
            Timeout = TimeSpan.FromMinutes(5);
        }
    }
}
