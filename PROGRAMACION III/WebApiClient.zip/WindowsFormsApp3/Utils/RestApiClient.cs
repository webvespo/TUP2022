﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public static class RestApiClient
    {


        private static CustomHttpClient apiClient = new CustomHttpClient(new Uri("http://localhost:24561"));

        /// <summary>
        /// Gets an entity from API.
        /// </summary>
        /// <typeparam name="T">Entity type.</typeparam>
        /// <param name="path">Path to API.</param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        public static async Task<T> GetEntity<T>(string path)
        {
            var response = await apiClient.GetAsync(path);

            return await ReadResponseContent<T>(response);
        }

        /// <summary>
        /// Gets an entity from API.
        /// </summary>
        /// <typeparam name="T">Entity type.</typeparam>
        /// <param name="path">Path to API.</param>
        /// <param name="cancellationToken">A cancellation token to cancel the task.</param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        public static async Task<T> GetEntity<T>(string path, CancellationToken? cancellationToken)
        {
            HttpResponseMessage response;

            if (cancellationToken.HasValue)
            {
                response = await apiClient.GetAsync(path, cancellationToken.Value);
            }
            else
            {
                response = await apiClient.GetAsync(path);
            }

            return await ReadResponseContent<T>(response);
        }

        /// <summary>
        /// Gets an entity from API using POST method.
        /// </summary>
        /// <typeparam name="T">Entity type.</typeparam>
        /// <param name="path">Path to API.</param>
        /// <param name="requestData">Data to send in the request body.</param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        public static async Task<T> GetEntityByPost<T>(string path, object requestData)
        {
            var response = await apiClient.PostAsJsonAsync(path, requestData);

            return await ReadResponseContent<T>(response);
        }

        /// <summary>
        /// Gets an entity from API using POST method.
        /// </summary>
        /// <typeparam name="T">Entity type.</typeparam>
        /// <param name="path">Path to API.</param>
        /// <param name="requestData">Data to send in the request body.</param>
        /// <param name="cancellationToken">A cancellation token to cancel the task.</param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        public static async Task<T> GetEntityByPost<T>(string path, object requestData, CancellationToken? cancellationToken)
        {
            HttpResponseMessage response;

            if (cancellationToken.HasValue)
            {
                response = await apiClient.PostAsJsonAsync(path, requestData, cancellationToken.Value);
            }
            else
            {
                response = await apiClient.PostAsJsonAsync(path, requestData);
            }

            return await ReadResponseContent<T>(response);
        }

        /// <summary>
        /// Save an entity.
        /// </summary>
        /// <typeparam name="TResult">Return entity type.</typeparam>
        /// <typeparam name="TEntity">Original Entity type.</typeparam>
        /// <param name="path">Path to API.</param>
        /// <param name="entity">Entity to save.</param>
        /// <returns>Result.</returns>
        public static async Task<TResult> SaveEntity<TResult, TEntity>(string path, TEntity entity)
        {
            try
            {
                var result = await apiClient.PostAsJsonAsync(path, entity);
                result.EnsureSuccessStatusCode();
                return await result.Content.ReadAsAsync<TResult>();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                return default(TResult);
            }
        }

        /// <summary>
        /// Update an entity.
        /// </summary>
        /// <typeparam name="TResult">Return entity type</typeparam>
        /// <typeparam name="TEntity">Entry entity type</typeparam>
        /// <param name="path">Path to api</param>
        /// <param name="entity">Entity to update</param>
        /// <returns>Result.</returns>
        public static async Task<TResult> UpdateEntity<TResult, TEntity>(string path, TEntity entity)
        {
            try
            {
                var result = await apiClient.PutAsJsonAsync(path, entity);
                result.EnsureSuccessStatusCode();
                return await result.Content.ReadAsAsync<TResult>();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                return default(TResult);
            }
        }

        /// <summary>
        /// Delete an entity.
        /// </summary>
        /// <typeparam name="T">Result type.</typeparam>
        /// <param name="path">Path to API.</param>
        /// <param name="entityId">Id of entity to delete.</param>
        /// <returns>Reult.</returns>
        public static async Task<T> DeleteEntity<T>(string path, long entityId)
        {
            try
            {
                var result = await apiClient.DeleteAsync($"{path}/{entityId}");
                result.EnsureSuccessStatusCode();
                return await result.Content.ReadAsAsync<T>();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                return default(T);
            }
        }

        private static async Task<T> ReadResponseContent<T>(HttpResponseMessage response)
        {
            try
            {
                response.EnsureSuccessStatusCode();

                return await response.Content.ReadAsAsync<T>();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");

                return default(T);
            }
        }
    }
}
