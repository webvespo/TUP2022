﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    public class CustomDelegatingHandler : DelegatingHandler
    {
        public CustomDelegatingHandler(HttpMessageHandler handler)
        {
            InnerHandler = handler;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
                                                                     CancellationToken cancellationToken)
        {

            HttpResponseMessage response = null;

            var responseBodyAsText = string.Empty;
            try
            {
                response = await base.SendAsync(request, cancellationToken);

                responseBodyAsText = await response.Content.ReadAsStringAsync();

                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                switch (response.StatusCode)
                {
                    case HttpStatusCode.Forbidden:
                        {
                            throw new Exception("Access denied.");
                        }

                    case HttpStatusCode.Unauthorized:
                        {
                            throw new Exception("You are not authorized or your session has expired.");
                        }

                    case HttpStatusCode.InternalServerError:
                        {
                            throw new Exception("An unexpected error has occurred on the server.");
                        }

                    case HttpStatusCode.BadRequest:
                        {
                            var index = responseBodyAsText.IndexOf("\n\n", StringComparison.InvariantCultureIgnoreCase);
                            if (index > 0)
                            {
                                responseBodyAsText = responseBodyAsText.Remove(index);
                            }

                            throw new Exception($"An error has occurred on the server.{Environment.NewLine}{responseBodyAsText}.");
                        }

                    case HttpStatusCode.NotFound:
                        {
                            throw new Exception("Server unreachable. Please verify settings.");
                        }

                    case HttpStatusCode.OK:
                        break;

                    default:
                        var defaultError = $"Internal error. Code: {response.StatusCode}";

                        throw new Exception(defaultError);
                }
            }

            return response;
        }
    }
}
