﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 newChild = new Form2();
            newChild.MdiParent = this;
            newChild.Show();

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            Form2 newChild = new Form2();
            newChild.MdiParent = this;
            newChild.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form2 newChild = new Form2();
            newChild.MdiParent = this;
            newChild.Show();
        }
    }
}
