﻿using System;

namespace MyFirstLibrary
{
    public class DateUtils
    {
        private readonly string[] validFormats = {"M/d/yyyy h:mm:ss tt", 
                                    "M/d/yyyy h:mm tt",
                                    "MM/dd/yyyy hh:mm:ss", 
                                    "M/d/yyyy h:mm:ss",
                                    "M/d/yyyy hh:mm tt", 
                                    "M/d/yyyy hh tt",
                                    "M/d/yyyy h:mm", 
                                    "M/d/yyyy h:mm",
                                    "MM/dd/yyyy hh:mm", 
                                    "M/dd/yyyy hh:mm"};
        public static string GetFormatedCurrentDateTime(string format)
        {
            if (!format.Contains(format))
            {
                return "Datetime format is invalid, please check";
            }

            var today = string.Empty;

            today = DateTime.Now.ToString(format);

            return today;
        }

        public static int RandomNumber()
        {
            Random rand = new Random();
            int number = rand.Next(0, 29);
            return number;
        }
    }


}
